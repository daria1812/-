from flask import Flask, render_template

app = Flask(__name__)


# Отслеживаем главную страницу
@app.route('/')
# Функция главной страницы
def index():
    return render_template('index.html')


# Отслеживаем страницу с контактами магазина
@app.route('/about')
def about():
    return render_template('about.html')


# Отслеживаем страницу с земельными участками
@app.route('/create')
def create():
    return render_template('create.html')


# Отслеживаем страницу с жильём
@app.route('/page')
def page():
    return render_template('page.html')


# Отслеживаем страницу с коммерческими объектами
@app.route('/market')
def market():
    return render_template('market.html')


# Проверка
if __name__ == "__main__":
    app.run()